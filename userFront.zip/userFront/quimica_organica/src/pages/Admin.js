import React, { useEffect } from 'react';

const Admin = () => {
  const getUrlParameter = (name) => {
    name = name.replace(/[[]/, '\\[').replace(/[\]]/, '\\]');
    const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    const results = regex.exec(window.location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
  };

  const errorMessage = getUrlParameter('mens');

  useEffect(() => {
    if (errorMessage) {
      alert(errorMessage);
    }
  }, [errorMessage]);

  return (
    <div className="login-box">
      <h2>Login</h2>
      <form action='http://localhost/quimicaOrganica/adminBack/loginVerifica.php' method='post'>
        <div className="user-box">
          <input type="email" name="email" id='email' required />
          <label htmlFor="email">Email:</label>
        </div>
        <div className="user-box">
          <input type="password" name="senha" id='senha' required />
          <label htmlFor="senha">Senha:</label>
        </div>
        <div className="centered-content">
          <input type="submit" name="envia" id='envia'className='SEND' value="SEND" />
        </div>
        {errorMessage && <p className="error-message">{errorMessage}</p>}
      </form>
    </div>
  );
};

export default Admin;
