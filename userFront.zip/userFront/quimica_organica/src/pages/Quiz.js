import React, { useState } from 'react';

const quizQuestions = [
  {
    question: "Qual é a fórmula molecular do metano?",
    options: ["CH4", "C2H6", "C3H8", "C4H10"],
    correctAnswer: "CH4"
  },
  {
    question: "Qual é o grupo funcional dos álcoois?",
    options: ["Hidroxila", "Carbonila", "Carboxila", "Amina"],
    correctAnswer: "Hidroxila"
  },
  {
    question: "Qual dos compostos é um alceno?",
    options: ["C2H4", "C3H8", "CH4", "C4H10"],
    correctAnswer: "C2H4"
  },
  {
    question: "Qual é o nome do composto com a fórmula molecular C2H2?",
    options: ["Etano", "Eteno", "Etino", "Metano"],
    correctAnswer: "Etino"
  },
  {
    question: "Qual é a principal característica dos compostos aromáticos?",
    options: ["Anéis de carbono", "Ligação tripla", "Ligação simples", "Grupo amina"],
    correctAnswer: "Anéis de carbono"
  },
  {
    question: "Qual dos compostos é um éter?",
    options: ["CH3-O-CH3", "CH3-CH2-OH", "CH3-COOH", "CH3-NH2"],
    correctAnswer: "CH3-O-CH3"
  },
  {
    question: "Qual é o grupo funcional dos ácidos carboxílicos?",
    options: ["Carboxila", "Carbonila", "Hidroxila", "Amina"],
    correctAnswer: "Carboxila"
  },
  {
    question: "Qual é o nome do composto com a fórmula molecular CH3-CH2-CH2-CH3?",
    options: ["Butano", "Propano", "Pentano", "Hexano"],
    correctAnswer: "Butano"
  },
  {
    question: "Qual dos seguintes compostos é um aldeído?",
    options: ["CH3CHO", "CH3OH", "CH3COOH", "CH3NH2"],
    correctAnswer: "CH3CHO"
  },
  {
    question: "Qual é a fórmula molecular do benzeno?",
    options: ["C6H6", "C6H12", "C5H10", "C4H8"],
    correctAnswer: "C6H6"
  }
];

const Quiz = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [showResults, setShowResults] = useState(false);

  const handleAnswer = (answer) => {
    setAnswers({
      ...answers,
      [currentQuestionIndex]: answer
    });
    const nextQuestionIndex = currentQuestionIndex + 1;
    if (nextQuestionIndex < quizQuestions.length) {
      setCurrentQuestionIndex(nextQuestionIndex);
    } else {
      setShowResults(true);
    }
  };

  const restartQuiz = () => {
    setCurrentQuestionIndex(0);
    setAnswers({});
    setShowResults(false);
  };

  if (showResults) {
    const incorrectAnswers = quizQuestions.filter((question, index) => question.correctAnswer !== answers[index]);
    
    return (
      <div className="quiz-container">
        <h2 className='quiz'>Resultado</h2>
        {incorrectAnswers.length === 0 ? (
          <p>Parabéns! Você acertou todas as perguntas.</p>
        ) : (
          <div>
            <p>Você errou {incorrectAnswers.length} perguntas:</p>
            <ul>
              {incorrectAnswers.map((question, index) => (
                <li key={index}>
                  <strong>Pergunta:</strong> {question.question} <br/>
                  <strong>Resposta correta:</strong> {question.correctAnswer} <br/>
                  <strong>Sua resposta:</strong> {answers[quizQuestions.indexOf(question)]}
                </li>
              ))}
            </ul>
          </div>
        )}
        <button onClick={restartQuiz}>Reiniciar Quiz</button>
      </div>
    );
  }

  const currentQuestion = quizQuestions[currentQuestionIndex];

  return (
    <div className="quiz-container">
      <h2 className='quiz'>Quiz de Química Orgânica</h2>
      <p>{currentQuestion.question}</p>
      <ul>
        {currentQuestion.options.map((option, index) => (
          <li key={index}>
            <button onClick={() => handleAnswer(option)}>{option}</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Quiz;
