import React, { useState, useEffect } from 'react';

const Compostos = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const fetchData = () => {
    const url = 'http://localhost/quimicaOrganica/'; // Substitua pela URL correta da sua API

    fetch(url)
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok, status: ${response.status}`);
        }
        return response.json(); // Expecting JSON response
      })
      .then(data => {
        setData(data);
        setLoading(false);
      })
      .catch(error => {
        setError(error);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleButtonClick = () => {
    setLoading(true); // Reset loading state when button is clicked
    fetchData();
  };

  const handleSearchChange = (event) => {
    setSearchTerm(event.target.value);
  };

  // Filtrar os dados com base no searchTerm
  const filteredData = data.filter(item => {
    return item.nome.toLowerCase().includes(searchTerm.toLowerCase());
  });

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    <div className='main'>
      <div className='search'>
        <div className="group">
          <svg className="icon" aria-hidden="true" viewBox="0 0 24 24">
            <g>
              <path d="M21.53 20.47l-3.66-3.66C19.195 15.24 20 13.214 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c2.215 0 4.24-.804 5.808-2.13l3.66 3.66c.147.146.34.22.53.22s.385-.073.53-.22c.295-.293.295-.767.002-1.06zM3.5 11c0-4.135 3.365-7.5 7.5-7.5s7.5 3.365 7.5 7.5-3.365 7.5-7.5 7.5-7.5-3.365-7.5-7.5z"></path>
            </g>
          </svg>
          <input 
            placeholder="Search" 
            type="search" 
            className="input" 
            value={searchTerm}
            onChange={handleSearchChange}
          />
        </div>
      </div>
      <div className='compostos'>
        {filteredData.map((item, index) => (
          <div className="card comp" key={index}>
            <div className="image">
              {item.images ? (
                <img
                  src={`http://localhost/quimicaOrganica/adminBack/imagem/${item.images}`}
                  alt="Imagem do Composto"
                  style={{ maxWidth: '100px', maxHeight: '100px' }}
                />
              ) : (
                <span>Imagem não disponível</span>
              )}
            </div>
            <div className="content">
              <a href="#">
                <span className="title">
                  Nome: {item.nome}
                </span>
              </a>
              <p className="desc">
                Fórmula Molecular: {item.formula_molecular}
              </p>
              <p className="desc">
                Estrutura Molecular: {item.estrutura_molecular}
              </p>
              <p className="desc">
                Grupo Funcional: {item.nome_grupo_funcional}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Compostos;
